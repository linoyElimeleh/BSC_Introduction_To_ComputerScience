#include <stdio.h>

void main()
{
	//import variable
	int inputNumber;
	//enter input from user
	printf("enter a number bigger than the number 0");
	scanf_s("%d", &inputNumber);
	//conditions and loops
	if (inputNumber < 0)
		printf("invalid input");
	else
		if (inputNumber < 10)
			printf("Number has 1 digit");
		else
			if (inputNumber < 100)
				printf("Number has 2 digit");
			else
				if (inputNumber < 1000)
					printf("Number has 3 digit");
				else
					printf("Number has more than 3 digits");
}